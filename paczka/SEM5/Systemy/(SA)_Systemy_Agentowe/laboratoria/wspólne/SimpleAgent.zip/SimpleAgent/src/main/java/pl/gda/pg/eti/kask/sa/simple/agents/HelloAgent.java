package pl.gda.pg.eti.kask.sa.simple.agents;

import jade.core.Agent;
import pl.gda.pg.eti.kask.sa.simple.behaviours.HelloBehaviour;

/**
 *
 * @author psysiu
 */
public class HelloAgent extends Agent {

    public HelloAgent() {
    }

    @Override
    protected void setup() {
        super.setup();
        this.addBehaviour(new HelloBehaviour(this));
    }

}
