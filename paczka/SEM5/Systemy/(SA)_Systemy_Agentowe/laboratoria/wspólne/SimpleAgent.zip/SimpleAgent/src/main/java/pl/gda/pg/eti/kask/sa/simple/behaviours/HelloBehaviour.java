package pl.gda.pg.eti.kask.sa.simple.behaviours;

import jade.core.Agent;
import jade.core.behaviours.OneShotBehaviour;
import javax.swing.JOptionPane;

/**
 *
 * @author psysiu
 */
public class HelloBehaviour extends OneShotBehaviour {

    public HelloBehaviour(Agent a) {
        super(a);
    }

    @Override
    public void action() {
        JOptionPane.showMessageDialog(null, "Hello there!\nMy name is "
                + myAgent.getAID().getLocalName()
                + "\nbut you can contact me via "
                + myAgent.getName());
    }

}
