/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.gda.pg.eti.kask.sa.mages.ontology;

import jade.content.onto.BeanOntology;
import jade.content.onto.BeanOntologyException;
import java.util.logging.Level;
import lombok.Getter;
import lombok.extern.java.Log;

/**
 *
 * @author psysiu
 */
@Log
public class SpellOntology extends BeanOntology {

    public static final String NAME = "spell-ontology";

    @Getter
    private static final SpellOntology instance = new SpellOntology(NAME);

    private SpellOntology(String name) {
        super(name);
        try {
            add(Spell.class);
            add(MemorizeSpell.class);
            add(ShowSpells.class);
        } catch (BeanOntologyException ex) {
            log.log(Level.SEVERE, null, ex);
        }

    }

}
