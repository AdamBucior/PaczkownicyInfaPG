package pl.gda.pg.eti.kask.sa.mages.agents;

import jade.content.lang.sl.SLCodec;
import jade.core.Agent;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import pl.gda.pg.eti.kask.sa.mages.behaviours.WaitingBehaviour;
import pl.gda.pg.eti.kask.sa.mages.ontology.Spell;
import pl.gda.pg.eti.kask.sa.mages.ontology.SpellOntology;

/**
 *
 * @author psysiu
 */
public class MageAgent extends Agent {

    @Getter
    protected final List<Spell> spells = new ArrayList<>();
    
    @Getter
    protected final List<String> activeConversationIds = new ArrayList<>();

    public MageAgent() {
    }

    @Override
    protected void setup() {
        super.setup();
        Object[] arguments = this.getArguments();
        for (Object argument : arguments) {
            spells.add(new Spell((String) argument));
        }
        getContentManager().registerLanguage(new SLCodec());
        getContentManager().registerOntology(SpellOntology.getInstance());
        addBehaviour(new WaitingBehaviour(this));
    }

}
