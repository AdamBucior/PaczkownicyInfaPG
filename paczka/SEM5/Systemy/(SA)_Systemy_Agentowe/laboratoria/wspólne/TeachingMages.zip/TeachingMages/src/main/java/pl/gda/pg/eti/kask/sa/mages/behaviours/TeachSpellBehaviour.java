package pl.gda.pg.eti.kask.sa.mages.behaviours;

import jade.core.AID;
import pl.gda.pg.eti.kask.sa.mages.agents.GrandMageAgent;
import pl.gda.pg.eti.kask.sa.mages.ontology.MemorizeSpell;

/**
 *
 * @author psysiu
 */
public class TeachSpellBehaviour extends RequestActionBehaviour<MemorizeSpell>{

    public TeachSpellBehaviour(GrandMageAgent agent, AID participant, MemorizeSpell action) {
        super(agent, participant, action);
    }

    @Override
    protected ReceiveResultBehaviour createResultBehaviour(String conversationId) {
        return new ReceiveTeachSpellResultBehaviour(myAgent, conversationId);
    }
    
}
