package pl.gda.pg.eti.kask.sa.mages.behaviours;

import jade.content.AgentAction;
import jade.content.Predicate;
import jade.content.lang.Codec;
import jade.content.lang.sl.SLCodec;
import jade.content.onto.OntologyException;
import jade.core.AID;
import jade.core.behaviours.OneShotBehaviour;
import jade.lang.acl.ACLMessage;
import java.util.logging.Level;
import lombok.extern.java.Log;
import pl.gda.pg.eti.kask.sa.mages.agents.MageAgent;
import pl.gda.pg.eti.kask.sa.mages.ontology.SpellOntology;

/**
 *
 * @author psysiu
 */
@Log
public abstract class ActionBehaviour<T extends AgentAction> extends OneShotBehaviour {

    protected final MageAgent myAgent;

    protected final String conversationId;
    
    protected final AID participant;
    
    protected final T action;
    
    public ActionBehaviour(MageAgent agent, T action, String conversationId, AID participant) {
        super(agent);
        this.myAgent = agent;
        this.action = action;
        this.conversationId = conversationId;
        this.participant = participant;
    }
    
    @Override
    public void action() {
        Predicate result = performAction();
        ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
        msg.setLanguage(new SLCodec().getName());
        msg.setOntology(SpellOntology.getInstance().getName());
        msg.setConversationId(conversationId);
        msg.addReceiver(participant);
        try {
            myAgent.getContentManager().fillContent(msg, result);
            myAgent.send(msg);
        } catch (Codec.CodecException | OntologyException ex) {
            log.log(Level.SEVERE, null, ex);
        }
    }

    protected abstract Predicate performAction();
}
