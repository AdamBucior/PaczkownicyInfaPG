package pl.gda.pg.eti.kask.sa.mages.behaviours;

import jade.core.AID;
import pl.gda.pg.eti.kask.sa.mages.agents.GrandMageAgent;
import pl.gda.pg.eti.kask.sa.mages.ontology.ShowSpells;

/**
 *
 * @author psysiu
 */
public class CheckSpellsBehaviour extends RequestActionBehaviour<ShowSpells>{

    public CheckSpellsBehaviour(GrandMageAgent agent, AID participant, ShowSpells action) {
        super(agent, participant, action);
    }

    @Override
    protected ReceiveResultBehaviour createResultBehaviour(String conversationId) {
        return new ReceiveCheckSpellsResultBehaviour(myAgent, conversationId);
    }
    
}
