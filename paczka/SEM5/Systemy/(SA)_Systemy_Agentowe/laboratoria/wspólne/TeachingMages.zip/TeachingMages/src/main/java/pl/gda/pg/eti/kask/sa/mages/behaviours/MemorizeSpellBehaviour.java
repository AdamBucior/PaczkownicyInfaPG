package pl.gda.pg.eti.kask.sa.mages.behaviours;

import jade.content.Predicate;
import jade.content.onto.basic.Action;
import jade.content.onto.basic.Done;
import jade.core.AID;
import lombok.extern.java.Log;
import pl.gda.pg.eti.kask.sa.mages.agents.MageAgent;
import pl.gda.pg.eti.kask.sa.mages.ontology.MemorizeSpell;

/**
 *
 * @author psysiu
 */
@Log
public class MemorizeSpellBehaviour extends ActionBehaviour<MemorizeSpell> {

    public MemorizeSpellBehaviour(MageAgent agent, MemorizeSpell action, String conversationId, AID participant) {
        super(agent, action, conversationId, participant);
    }

    @Override
    protected Predicate performAction() {
        myAgent.getSpells().add(action.getSpell());
        return new Done(new Action(myAgent.getAID(), action));
    }
    
   
    
}
