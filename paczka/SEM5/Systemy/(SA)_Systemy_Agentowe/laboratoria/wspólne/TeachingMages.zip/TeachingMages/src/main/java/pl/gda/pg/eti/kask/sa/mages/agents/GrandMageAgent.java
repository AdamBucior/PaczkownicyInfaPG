package pl.gda.pg.eti.kask.sa.mages.agents;

import jade.core.AID;
import pl.gda.pg.eti.kask.sa.mages.behaviours.TeachSpellBehaviour;
import pl.gda.pg.eti.kask.sa.mages.ontology.MemorizeSpell;

/**
 *
 * @author psysiu
 */
public class GrandMageAgent extends MageAgent {

    public GrandMageAgent() {
    }
    
    @Override
    protected void setup() {
        super.setup();
        addBehaviour(new TeachSpellBehaviour(this, new AID("student", false), new MemorizeSpell(spells.get(0))));
    }
    
}
