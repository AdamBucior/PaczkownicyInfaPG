package pl.gda.pg.eti.kask.sa.mages.behaviours;

import jade.content.Predicate;
import jade.content.onto.basic.Result;
import jade.core.AID;
import jade.util.leap.List;
import javax.swing.JOptionPane;
import pl.gda.pg.eti.kask.sa.mages.agents.GrandMageAgent;
import pl.gda.pg.eti.kask.sa.mages.ontology.Spell;

/**
 *
 * @author psysiu
 */
public class ReceiveCheckSpellsResultBehaviour extends ReceiveResultBehaviour {

    public ReceiveCheckSpellsResultBehaviour(GrandMageAgent agent, String conversationId) {
        super(agent, conversationId);
    }

    @Override
    protected void handleResult(Predicate predicate, AID participant) {
        if (predicate instanceof Result) {
            List spells = ((Result) predicate).getItems();
            StringBuilder sb = new StringBuilder();
            spells.iterator().forEachRemaining(s -> {
                sb.append(((Spell) s).getName()).append("\n");
            });
            JOptionPane.showMessageDialog(null, sb.toString());
        }
    }

}
