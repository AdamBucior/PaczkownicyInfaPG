package pl.gda.pg.eti.kask.sa.mages.behaviours;

import jade.content.Concept;
import jade.content.ContentElement;
import jade.content.lang.Codec;
import jade.content.onto.OntologyException;
import jade.content.onto.basic.Action;
import jade.core.AID;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import java.util.logging.Level;
import lombok.extern.java.Log;
import pl.gda.pg.eti.kask.sa.mages.agents.MageAgent;
import pl.gda.pg.eti.kask.sa.mages.ontology.MemorizeSpell;
import pl.gda.pg.eti.kask.sa.mages.ontology.ShowSpells;

/**
 *
 * @author psysiu
 */
@Log
public class WaitingBehaviour extends CyclicBehaviour {

    protected final MageAgent myAgent;

    public WaitingBehaviour(MageAgent agent) {
        super(agent);
        myAgent = agent;
    }

    @Override
    public void action() {
        MessageTemplate mt = MessageTemplate.MatchAll();
        for (String id : myAgent.getActiveConversationIds()) {
            mt = MessageTemplate.and(mt, MessageTemplate.not(MessageTemplate.MatchConversationId(id)));
        }
        ACLMessage message = myAgent.receive(mt);
        if (message != null) {
            try {
                ContentElement ce = myAgent.getContentManager().extractContent(message);
                if (ce instanceof Action) {
                    action((Action) ce, message.getConversationId(), message.getSender());
                }
            } catch (Codec.CodecException | OntologyException ex) {
                log.log(Level.SEVERE, null, ex);
            }
        }
    }
    
    private void action(Action action, String conversationId, AID participant) {
        Concept a = action.getAction();
        if (a instanceof MemorizeSpell) {
            action((MemorizeSpell) a, conversationId, participant);
        } else if (a instanceof ShowSpells) {
            action((ShowSpells) a, conversationId, participant);
        }
    }
    
    private void action(MemorizeSpell ms, String conversationId, AID participant) {
        myAgent.addBehaviour(new MemorizeSpellBehaviour(myAgent, ms, conversationId, participant));
    }
    
    private void action(ShowSpells ss, String conversationId, AID participant) {
        myAgent.addBehaviour(new ShowSpellsBehaviour(myAgent, ss, conversationId, participant));
    }

}
