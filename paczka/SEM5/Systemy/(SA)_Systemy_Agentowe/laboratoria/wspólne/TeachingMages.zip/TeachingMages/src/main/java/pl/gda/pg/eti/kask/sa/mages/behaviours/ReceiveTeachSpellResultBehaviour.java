package pl.gda.pg.eti.kask.sa.mages.behaviours;

import jade.content.Predicate;
import jade.content.onto.basic.Done;
import jade.core.AID;
import pl.gda.pg.eti.kask.sa.mages.agents.GrandMageAgent;
import pl.gda.pg.eti.kask.sa.mages.ontology.ShowSpells;

/**
 *
 * @author psysiu
 */
public class ReceiveTeachSpellResultBehaviour extends ReceiveResultBehaviour {

    public ReceiveTeachSpellResultBehaviour(GrandMageAgent agent, String conversationId) {
        super(agent, conversationId);
    }

    @Override
    protected void handleResult(Predicate predicate, AID participant) {
        if (predicate instanceof Done) {
            myAgent.addBehaviour(new CheckSpellsBehaviour(myAgent, participant, new ShowSpells()));
        }
    }

}
