package pl.gda.pg.eti.kask.sa.mages.behaviours;

import jade.content.Predicate;
import jade.content.onto.basic.Action;
import jade.content.onto.basic.Result;
import jade.core.AID;
import jade.util.leap.ArrayList;
import jade.util.leap.List;
import lombok.extern.java.Log;
import pl.gda.pg.eti.kask.sa.mages.agents.MageAgent;
import pl.gda.pg.eti.kask.sa.mages.ontology.ShowSpells;

/**
 *
 * @author psysiu
 */
@Log
public class ShowSpellsBehaviour extends ActionBehaviour<ShowSpells> {

    public ShowSpellsBehaviour(MageAgent agent, ShowSpells action, String conversationId, AID participant) {
        super(agent, action, conversationId, participant);
    }

    @Override
    protected Predicate performAction() {
        Result result = new Result();
        result.setAction(new Action(myAgent.getAID(), action));
        List resultList = new ArrayList();
        myAgent.getSpells().forEach(s -> {
            resultList.add(s);
        });
        result.setItems(resultList);
        return result;
    }

}
