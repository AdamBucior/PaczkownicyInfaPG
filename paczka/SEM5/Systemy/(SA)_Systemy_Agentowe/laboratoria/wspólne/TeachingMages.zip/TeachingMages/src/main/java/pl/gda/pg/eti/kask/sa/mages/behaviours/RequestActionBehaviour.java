package pl.gda.pg.eti.kask.sa.mages.behaviours;

import jade.content.AgentAction;
import jade.content.lang.Codec;
import jade.content.lang.sl.SLCodec;
import jade.content.onto.OntologyException;
import jade.content.onto.basic.Action;
import jade.core.AID;
import jade.core.behaviours.OneShotBehaviour;
import jade.lang.acl.ACLMessage;
import java.util.UUID;
import java.util.logging.Level;
import lombok.extern.java.Log;
import pl.gda.pg.eti.kask.sa.mages.agents.GrandMageAgent;
import pl.gda.pg.eti.kask.sa.mages.ontology.SpellOntology;

/**
 *
 * @author psysiu
 */
@Log
public abstract class RequestActionBehaviour<T extends AgentAction> extends OneShotBehaviour {

    protected final GrandMageAgent myAgent;
    
    private final AID participant;

    private final T action;

    public RequestActionBehaviour(GrandMageAgent agent, AID participant, T action) {
        this.participant = participant;
        this.action = action;
        this.myAgent = agent;
    }
    
    @Override
    public void action() {
        Action action = new Action(participant, this.action);

        String conversationId = UUID.randomUUID().toString();
        
        ACLMessage request = new ACLMessage(ACLMessage.REQUEST);
        request.setLanguage(new SLCodec().getName());
        request.setOntology(SpellOntology.getInstance().getName());
        request.addReceiver(participant);
        request.setConversationId(conversationId);
        
        try {
            myAgent.getContentManager().fillContent(request, action);
            myAgent.getActiveConversationIds().add(conversationId);
            myAgent.send(request);
            myAgent.addBehaviour(createResultBehaviour(conversationId));
        } catch (Codec.CodecException | OntologyException ex) {
            log.log(Level.WARNING, ex.getMessage(), ex);
        }
    }
    
    protected abstract ReceiveResultBehaviour createResultBehaviour(String conversationId);

}
